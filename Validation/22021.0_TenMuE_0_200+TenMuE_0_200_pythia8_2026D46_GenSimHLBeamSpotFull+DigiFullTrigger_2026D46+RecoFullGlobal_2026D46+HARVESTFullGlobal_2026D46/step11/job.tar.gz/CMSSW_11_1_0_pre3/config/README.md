# This repo contains configuration files for every project that can be build by SCRAM.
