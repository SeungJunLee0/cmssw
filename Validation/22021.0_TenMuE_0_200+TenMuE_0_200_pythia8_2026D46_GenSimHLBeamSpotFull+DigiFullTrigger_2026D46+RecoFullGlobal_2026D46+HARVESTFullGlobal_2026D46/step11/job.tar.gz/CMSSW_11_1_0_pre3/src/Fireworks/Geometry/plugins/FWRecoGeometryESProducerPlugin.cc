#include "Fireworks/Geometry/interface/FWRecoGeometryESProducer.h"
#include "FWCore/Framework/interface/ModuleFactory.h"

DEFINE_FWK_EVENTSETUP_MODULE(FWRecoGeometryESProducer);
