#include "Fireworks/Geometry/interface/FWTGeoRecoGeometryESProducer.h"
#include "FWCore/Framework/interface/ModuleFactory.h"

DEFINE_FWK_EVENTSETUP_MODULE(FWTGeoRecoGeometryESProducer);
