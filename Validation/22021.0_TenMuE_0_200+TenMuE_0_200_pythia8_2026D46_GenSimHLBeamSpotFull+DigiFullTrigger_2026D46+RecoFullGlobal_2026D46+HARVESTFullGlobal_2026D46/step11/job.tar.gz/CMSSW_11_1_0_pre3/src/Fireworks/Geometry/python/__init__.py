#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/Fireworks/Geometry/',1)[0])+'/cfipython/slc7_amd64_gcc820/Fireworks/Geometry')
