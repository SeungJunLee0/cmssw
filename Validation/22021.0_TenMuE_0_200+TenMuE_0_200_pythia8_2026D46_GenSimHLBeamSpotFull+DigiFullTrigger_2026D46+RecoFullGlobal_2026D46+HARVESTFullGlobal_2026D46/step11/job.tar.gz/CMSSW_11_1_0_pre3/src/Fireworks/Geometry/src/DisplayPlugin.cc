// -*- C++ -*-
//
// Package:     Geometry
// Class  :     DisplayPlugin
//
// Implementation:
//     [Notes on implementation]
//
// Original Author:
//         Created:  Thu Mar 18 04:09:19 CDT 2010
//

// system include files

// user include files
#include "Fireworks/Geometry/interface/DisplayPlugin.h"

using namespace fireworks::geometry;
//
// constants, enums and typedefs
//

//
// static data member definitions
//

//
// constructors and destructor
//
DisplayPlugin::DisplayPlugin() {}

// DisplayPlugin::DisplayPlugin(const DisplayPlugin& rhs)
// {
//    // do actual copying here;
// }

DisplayPlugin::~DisplayPlugin() {}

//
// assignment operators
//
// const DisplayPlugin& DisplayPlugin::operator=(const DisplayPlugin& rhs)
// {
//   //An exception safe implementation is
//   DisplayPlugin temp(rhs);
//   swap(rhs);
//
//   return *this;
// }

//
// member functions
//

//
// const member functions
//

//
// static member functions
//
