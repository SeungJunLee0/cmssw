#include "Geometry/GEMGeometry/interface/ME0Geometry.h"
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(ME0Geometry);
