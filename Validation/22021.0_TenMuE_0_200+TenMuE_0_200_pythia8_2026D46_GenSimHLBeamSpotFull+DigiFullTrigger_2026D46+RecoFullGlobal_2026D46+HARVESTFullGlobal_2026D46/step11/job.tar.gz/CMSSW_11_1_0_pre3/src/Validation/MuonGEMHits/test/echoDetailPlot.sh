#!/bin/bash
echo "process.gemSimHitValidation.detailPlot = cms.bool(True)
process.gemSimTrackValidation.detailPlot = cms.bool(True)
process.gemStripValidation.detailPlot = cms.bool(True)
process.gemPadValidation.detailPlot = cms.bool(True)
process.gemCoPadValidation.detailPlot = cms.bool(True)
process.gemDigiTrackValidation.detailPlot = cms.bool(True)
process.gemGeometryChecker.detailPlot = cms.bool(True)
process.gemRecHitsValidation.detailPlot = cms.bool(True)
process.gemRecHitTrackValidation.detailPlot = cms.bool(True)
" 
