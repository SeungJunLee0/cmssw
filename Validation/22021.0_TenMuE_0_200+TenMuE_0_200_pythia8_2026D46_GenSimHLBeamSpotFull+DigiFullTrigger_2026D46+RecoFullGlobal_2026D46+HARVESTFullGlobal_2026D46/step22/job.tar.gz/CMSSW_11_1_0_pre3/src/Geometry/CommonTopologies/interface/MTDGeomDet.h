#ifndef CommonDet_MTDGeomDet_H
#define CommonDet_MTDGeomDet_H

#include "Geometry/CommonTopologies/interface/TrackerGeomDet.h"

using MTDGeomDet = TrackerGeomDet;
#endif
