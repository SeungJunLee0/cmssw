#include "Geometry/CommonTopologies/interface/MuonGeomDet.h"

bool MuonGeomDet::setAlignmentPositionError(const AlignmentPositionError& ape) {
  //this is a placeholder, global to local conversion is done in the MuonTransientTrackingRecHit at the moment
  return true;
}
