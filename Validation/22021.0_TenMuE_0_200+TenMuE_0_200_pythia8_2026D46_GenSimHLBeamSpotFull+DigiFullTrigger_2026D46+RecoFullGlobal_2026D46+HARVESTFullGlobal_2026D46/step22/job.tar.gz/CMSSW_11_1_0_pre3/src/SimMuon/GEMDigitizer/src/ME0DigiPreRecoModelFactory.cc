#include "FWCore/PluginManager/interface/PluginFactory.h"

#include "SimMuon/GEMDigitizer/interface/ME0DigiPreRecoModelFactory.h"
EDM_REGISTER_PLUGINFACTORY(ME0DigiPreRecoModelFactory, "ME0DigiPreRecoModelFactory");
