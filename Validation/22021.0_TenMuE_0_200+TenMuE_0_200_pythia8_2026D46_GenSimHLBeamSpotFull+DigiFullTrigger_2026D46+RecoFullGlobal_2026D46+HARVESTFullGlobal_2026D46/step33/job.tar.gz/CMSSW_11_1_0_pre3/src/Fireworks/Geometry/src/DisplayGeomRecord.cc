// -*- C++ -*-
//
// Package:     Geometry
// Class  :     DisplayGeomRecord
//
// Implementation:
//     [Notes on implementation]
//
// Author:
// Created:     Thu Mar 18 16:19:57 CDT 2010

#include "Fireworks/Geometry/interface/DisplayGeomRecord.h"
#include "FWCore/Framework/interface/eventsetuprecord_registration_macro.h"

EVENTSETUP_RECORD_REG(DisplayGeomRecord);
