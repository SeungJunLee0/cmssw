#include "Fireworks/Geometry/interface/FWTGeoRecoGeometry.h"
#include <FWCore/Utilities/interface/typelookup.h>

TYPELOOKUP_DATA_REG(FWTGeoRecoGeometry);
