#include "Fireworks/Geometry/interface/FWTGeoRecoGeometry.h"

FWTGeoRecoGeometry::FWTGeoRecoGeometry(void) : m_manager(nullptr) {}

FWTGeoRecoGeometry::~FWTGeoRecoGeometry(void) {}
