// -*- C++ -*-
//
// Package:     Geometry
// Class  :     Reg_TGeoManager
//
// Implementation:
//     [Notes on implementation]
//
// Original Author:
//         Created:  Thu Mar 18 17:03:10 CDT 2010
//

// system include files
#include "TGeoManager.h"
// user include files
#include "FWCore/Utilities/interface/typelookup.h"

TYPELOOKUP_DATA_REG(TGeoManager);
