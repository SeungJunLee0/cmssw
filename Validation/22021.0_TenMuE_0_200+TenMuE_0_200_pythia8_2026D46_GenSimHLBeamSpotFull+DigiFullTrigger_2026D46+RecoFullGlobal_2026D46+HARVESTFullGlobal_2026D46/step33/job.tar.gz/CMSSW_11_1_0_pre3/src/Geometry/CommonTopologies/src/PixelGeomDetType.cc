// #include "Geometry/CommonTopologies/interface/PixelGeomDetType.h"

// void PixelGeomDetType::setTopology( TopologyType* topol)
// {
//   if (topol != theTopology) {
//     delete theTopology;
//     theTopology = topol;
//   }
// }
