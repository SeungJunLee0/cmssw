#ifndef RecoLocalMuon_GEMRecHit_GEMClusterContainer_h
#define RecoLocalMuon_GEMRecHit_GEMClusterContainer_h
#include <set>

class GEMCluster;
typedef std::set<GEMCluster> GEMClusterContainer;
#endif
