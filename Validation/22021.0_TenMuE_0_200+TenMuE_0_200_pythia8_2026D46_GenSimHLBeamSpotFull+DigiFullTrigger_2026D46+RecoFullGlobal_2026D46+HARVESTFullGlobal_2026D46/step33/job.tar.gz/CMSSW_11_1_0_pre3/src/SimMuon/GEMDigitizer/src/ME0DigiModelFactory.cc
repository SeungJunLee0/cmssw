#include "FWCore/PluginManager/interface/PluginFactory.h"

#include "SimMuon/GEMDigitizer/interface/ME0DigiModelFactory.h"
EDM_REGISTER_PLUGINFACTORY(ME0DigiModelFactory, "ME0DigiModelFactory");
